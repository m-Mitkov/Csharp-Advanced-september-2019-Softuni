﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
  public class StartUp
    {
       public static void Main(string[] args)
        {
            List<Person> people = new List<Person>();

            Person person = new Person();
            person.Name = ("Pesho");
            person.Age = 20;

            Person person2 = new Person();
            person2.Name = "Gosho";
            person2.Age = 18;

            Person person3 = new Person();
            person3.Name = "Stamat";
            person3.Age = 43;

            people.Add(person);
            people.Add(person2);
            people.Add(person3);

            foreach (var currentPerson in people)
            {
                Console.WriteLine($"{currentPerson.Name} {currentPerson.Age}");
            }
        }
    }
}
