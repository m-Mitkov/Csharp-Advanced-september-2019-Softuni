﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericBox
{
    class Box<T>
    {
        private T items;

        public Box(T item)
        {
            this.items = item;
        }

        public override string ToString()
        {
            return $"{this.items.GetType()}: {this.items}";
        }
    }
}
