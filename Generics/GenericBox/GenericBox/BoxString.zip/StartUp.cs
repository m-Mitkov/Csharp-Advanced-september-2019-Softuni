﻿using System;

namespace GenericBox
{
    class StartUp
    {
        static void Main(string[] args)
        {
            int numberOfInputs = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfInputs; i++)
            {
                string inputItem = Console.ReadLine();
                Box<string> item = new Box<string>(inputItem);
                Console.WriteLine(item.ToString());
            }
        }
    }
}
