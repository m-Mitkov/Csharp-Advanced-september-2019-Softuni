﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SoftUniParking
{
    public class StartUp
    {
        static void Main(string[] args)
        {
        }
    }
}
