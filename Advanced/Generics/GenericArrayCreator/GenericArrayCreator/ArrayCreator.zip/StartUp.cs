﻿using System;

namespace GenericArrayCreator
{
    class StartUp
    {
        static void Main(string[] args)
        {
            //int[] intArray = ArrayCreator<int>.Create(10, 33);

            //Console.Write(string.Join(" ", intArray));
            //Console.WriteLine();

            //string[] stringArray = ArrayCreator<string>.Create(5, "Pesho");

            //Console.Write(string.Join(" ", stringArray));
        }
    }
}
