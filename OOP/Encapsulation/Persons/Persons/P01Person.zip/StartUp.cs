﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PersonsInfo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var inputCount = int.Parse(Console.ReadLine());
            var people = new List<Person>();

            for (int i = 0; i < inputCount; i++)
            {
                var currentPerson = Console.ReadLine()
                    .Split(" ");

                var person = new Person(currentPerson[0], currentPerson[1], int.Parse(currentPerson[2]));
                people.Add(person);
            }

            people.OrderBy(p => p.FirstName)
                .ThenBy(p => p.Age)
                .ToList()
                .ForEach(x => Console.WriteLine(x));
        }
    }
}
