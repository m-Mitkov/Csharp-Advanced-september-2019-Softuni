﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PersonsInfo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var inputCount = int.Parse(Console.ReadLine());
            var people = new List<Person>();

            for (int i = 0; i < inputCount; i++)
            {
                var currentPerson = Console.ReadLine()
                    .Split(" ");
                try
                {
                    var person = new Person(currentPerson[0], currentPerson[1],
                        int.Parse(currentPerson[2]), decimal.Parse(currentPerson[3]));

                    people.Add(person);
                }

                catch (ArgumentException ex)
                {
                    Console.WriteLine(ex.Message.ToString());
                }
            }

            var percentageSalaryIncrease = decimal.Parse(Console.ReadLine());
            people.ForEach(x => x.IncreaseSalary(percentageSalaryIncrease));
            people.ForEach(x => Console.WriteLine(x));
        }
    }
}
