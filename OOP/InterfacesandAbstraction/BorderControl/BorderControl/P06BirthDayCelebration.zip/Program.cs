﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {

            List<IBithable> database = new List<IBithable>();
            while (true)
            {
                string[] input = Console.ReadLine()
                    .Split(" ");

                if (input[0] == "End")
                {
                    break;
                }

                if (input[0] == "Citizen")
                {
                    string name = input[1];
                    int age = int.Parse(input[2]);
                    string id = input[3];

                    DateTime birthdate = DateTime.ParseExact(input[4], "dd/MM/yyyy", null);

                    database.Add(new Person(name, age, id, birthdate));
                }

                else if (input[0] == "Pet")
                {
                    string name = input[1];

                    DateTime birthdate = DateTime.ParseExact(input[2], "dd/MM/yyyy", null);

                    database.Add(new Pet(name, birthdate));
                }
            }

            int year = int.Parse(Console.ReadLine());

            database.Where(x => x.BirthDay.Year == year)
                  .ToList()
                  .ForEach(x => Console.WriteLine(string.Format($"{x.BirthDay:dd/MM/yyyy}")));
        }
    }
}
