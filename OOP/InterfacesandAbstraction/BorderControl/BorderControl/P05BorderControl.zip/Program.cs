﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {

            List<ICountable> database = new List<ICountable>();
            while (true)
            {
                string[] input = Console.ReadLine()
                    .Split(" ");

                if (input[0] == "End")
                {
                    break;
                }

                ICountable checkedPersonOrRobot;

                if (input.Length == 3)
                {
                    string name = input[0];
                    int age = int.Parse(input[1]);
                    string id = input[2];

                    checkedPersonOrRobot = new Person(name, age, id);
                }

                else
                {
                    string name = input[0];
                    string id = input[1];

                   checkedPersonOrRobot = new Robot(name, id);
                }

                database.Add(checkedPersonOrRobot);
            }

            string securityCodeToCheck = Console.ReadLine();

            foreach (var item in database)
            {
                if (item.CheckBorderControllPassed(securityCodeToCheck))
                {
                    Console.WriteLine(item.Id);
                }
            }
        }
    }
}
