﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
    class Person : ICountable
    {
        public Person(string name, int age, string id)
        {
            this.Name = name;
            this.Age = age;
            this.Id = id;
        }

        public string Name { get; set; }

        public int Age { get; set; }

        public string Id { get; set; }

        public bool CheckBorderControllPassed(string specificCode)
        {
            if (Id.Substring(Id.Length - specificCode.Length, specificCode.Length) == specificCode)
            {
                return true;
            }

            return false;
        }
    }
}
