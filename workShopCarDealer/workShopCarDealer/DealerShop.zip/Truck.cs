﻿using System;
using System.Collections.Generic;
using System.Text;

namespace workShopCarDealer
{
    class Truck
    {
    }
}
